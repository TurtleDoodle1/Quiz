/**
 * 
 */
/**
 * 
 */
module Quiz {
	requires java.desktop;
}