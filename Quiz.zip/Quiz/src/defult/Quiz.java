package defult;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class Quiz implements ActionListener {
	
	String[] questions = {
			"Kızınca tüküren hayvan hangisidir?",
			"Yerden fıskırarak çıkan sıcak su kaynaklarına ne denir?",
			"Depremin büyüklügünü ve süresini ölçen alete ne ad verilir ?"
	};
	
	String [][] options = {
			{"Panda", "Kaplan", "Aslan", "Lama"},
			{"Gayzer", "Lav", "Toprak", "Su"},
			{"Tomograf", "Kumpas", "Sismograf", "Takometre"}
	};
	
	char[] answers = {'D', 'A', 'C'};
	
	char guess;
	char answer;
	int i;
	int correct_guesses = 0;
	int total_questions = questions.length;
	int result;
	int seconds = 10;
	
	
	JFrame frame = new JFrame();
	JTextField text_field = new JTextField(); //JTextArea has multiple text lines
	JTextArea text_area = new JTextArea(); //JTextField is editable and has only one line
	JButton buttonA = new JButton();
	JButton buttonB = new JButton();
	JButton buttonC = new JButton();
	JButton buttonD = new JButton();
	JLabel answerlabelA = new JLabel(); //JLabel is not editable
	JLabel answerlabelB = new JLabel();
	JLabel answerlabelC = new JLabel();
	JLabel answerlabelD = new JLabel();
	JLabel time_label = new JLabel();
	JLabel seconds_left = new JLabel();
	JTextField number_right = new JTextField();
	JTextField percentage = new JTextField();
	
	Timer timer = new Timer(1000,new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			seconds--;
			seconds_left.setText(String.valueOf(seconds));
			if (seconds <=0) {
				displayAnswer();
			}
		}	
	});


	Quiz(){
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(650,650);
		frame.getContentPane().setBackground(new Color(50,50,50)); //getcontentpane allows object additions
		frame.setResizable(false);
		frame.setLayout(null);
		
		text_field.setBounds(0, 0, 650, 50);
		text_field.setBackground(new Color(25,25,25));
		text_field.setForeground(new Color(25,255,0));
		text_field.setFont(new Font("Ink Free", Font.BOLD, 30));
		text_field.setBorder(BorderFactory.createBevelBorder(1));
		text_field.setHorizontalAlignment(JTextField.CENTER);
		text_field.setEditable(false);
		
		text_area.setBounds(0, 50, 650, 50);
		text_area.setLineWrap(true);
		text_area.setWrapStyleWord(true); //allows sentence to continue on the next line at the bottom
		text_area.setBackground(new Color(25,25,25));
		text_area.setForeground(new Color(25,255,0));
		text_area.setFont(new Font("MV Boli", Font.BOLD, 20));
		text_area.setBorder(BorderFactory.createBevelBorder(1));
		text_area.setEditable(false);
		
		buttonA.setBounds(0,100,100,100);
		buttonA.setFont(new Font("MV Boli", Font.BOLD, 35));
		buttonA.setText("A");
		buttonA.setFocusable(false);
		buttonA.addActionListener(this);
		
		buttonB.setBounds(0,200,100,100);
		buttonB.setFont(new Font("MV Boli", Font.BOLD, 35));
		buttonB.setText("B");
		buttonB.setFocusable(false);
		buttonB.addActionListener(this);
		
		buttonC.setBounds(0,300,100,100);
		buttonC.setFont(new Font("MV Boli", Font.BOLD, 35));
		buttonC.setText("C");
		buttonC.setFocusable(false);
		buttonC.addActionListener(this);
		
		buttonD.setBounds(0,400,100,100);
		buttonD.setFont(new Font("MV Boli", Font.BOLD, 35));
		buttonD.setText("D");
		buttonD.setFocusable(false);
		buttonD.addActionListener(this);
		
		answerlabelA.setBounds(125,100,500,100);
		answerlabelA.setBackground(new Color(50,50,50));
		answerlabelA.setForeground(new Color(25,255,0));
		answerlabelA.setFont(new Font("MV Boli", Font.PLAIN, 35));
		
		answerlabelB.setBounds(125,200,500,100);
		answerlabelB.setBackground(new Color(50,50,50));
		answerlabelB.setForeground(new Color(25,255,0));
		answerlabelB.setFont(new Font("MV Boli", Font.PLAIN, 35));
		
		answerlabelC.setBounds(125,300,500,100);
		answerlabelC.setBackground(new Color(50,50,50));
		answerlabelC.setForeground(new Color(25,255,0));
		answerlabelC.setFont(new Font("MV Boli", Font.PLAIN, 35));
		
		answerlabelD.setBounds(125,400,500,100);
		answerlabelD.setBackground(new Color(50,50,50));
		answerlabelD.setForeground(new Color(25,255,0));
		answerlabelD.setFont(new Font("MV Boli", Font.PLAIN, 35));
		
		seconds_left.setBounds(535,510,100,100);
		seconds_left.setBackground(new Color(25,25,25));
		seconds_left.setForeground(new Color(255,0,0));
		seconds_left.setFont(new Font("Ink Free", Font.BOLD, 60));
		seconds_left.setOpaque(true);
		seconds_left.setHorizontalAlignment(JLabel.CENTER);
		seconds_left.setBorder(BorderFactory.createBevelBorder(1));
		seconds_left.setText(String.valueOf(seconds));
		
		time_label.setBounds(535,475,100,25);
		time_label.setBackground(new Color(50,50,50));
		time_label.setForeground(new Color(255,0,0));
		time_label.setFont(new Font("MV Boli", Font.PLAIN, 20));
		time_label.setText("Timer!");
		time_label.setOpaque(true);
		time_label.setHorizontalAlignment(JLabel.CENTER);
		
		number_right.setBounds(225,225,200,100); //these two are results so we will add them alter
		number_right.setBackground(new Color(25,25,25));
		number_right.setForeground(new Color(25,255,0));
		number_right.setFont(new Font("Ink Free",Font.BOLD,50));
		number_right.setBorder(BorderFactory.createBevelBorder(1));
		number_right.setHorizontalAlignment(JTextField.CENTER);
		number_right.setEditable(false);
		
		percentage.setBounds(225,325,200,100);
		percentage.setBackground(new Color(25,25,25));
		percentage.setForeground(new Color(25,255,0));
		percentage.setFont(new Font("Ink Free",Font.BOLD,50));
		percentage.setBorder(BorderFactory.createBevelBorder(1));
		percentage.setHorizontalAlignment(JTextField.CENTER);
		percentage.setEditable(false);


		frame.add(time_label);
		frame.add(seconds_left);
		frame.add(buttonA);
		frame.add(buttonB);
		frame.add(buttonC);
		frame.add(buttonD);
		frame.add(answerlabelA);
		frame.add(answerlabelB);
		frame.add(answerlabelC);
		frame.add(answerlabelD);
		frame.add(text_field);
		frame.add(text_area);
		frame.setVisible(true);
		nextQuestion();
	}
	
	public void nextQuestion() {
		if(i>=total_questions) {
			result();
		}
		else {
			text_field.setText("Question " + (i+1));
			text_area.setText(questions[i]);
			answerlabelA.setText(options[i][0]);
			answerlabelB.setText(options[i][1]);
			answerlabelC.setText(options[i][2]);
			answerlabelD.setText(options[i][3]);
			timer.start();
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		buttonA.setEnabled(false);
		buttonB.setEnabled(false);
		buttonC.setEnabled(false);
		buttonD.setEnabled(false);
		if(e.getSource() == buttonA) {
			answer = 'A';
			if(answer == answers[i]) {
				correct_guesses++;
			}
		}
		if(e.getSource() == buttonB) {
			answer = 'B';
			if(answer == answers[i]) {
				correct_guesses++;
			}
		}
		
		if(e.getSource() == buttonC) {
			answer = 'C';
			if(answer == answers[i]) {
				correct_guesses++;
			}
		}
		
		if(e.getSource() == buttonD) {
			answer = 'D';
			if(answer == answers[i]) {
				correct_guesses++;
			}
		}
		displayAnswer();
	}
	
	public void result() {
		buttonA.setEnabled(false);
		buttonB.setEnabled(false);
		buttonC.setEnabled(false);
		buttonD.setEnabled(false);
		text_field.setText("RESULTS!");
		text_area.setText("");
		answerlabelA.setText("");
		answerlabelB.setText("");
		answerlabelC.setText("");
		answerlabelD.setText("");
		
		result = (int)((correct_guesses /(double)total_questions) * 100);
		
		number_right.setText(correct_guesses + "/" + total_questions);
		percentage.setText(result + "%");
		
		frame.add(number_right);
		frame.add(percentage);
	}
	
	public void displayAnswer() {
		timer.stop();
		buttonA.setEnabled(false);
		buttonB.setEnabled(false);
		buttonC.setEnabled(false);
		buttonD.setEnabled(false);
		
		if(answers[i] != 'A') {answerlabelA.setForeground(new Color(255,0,0));}
		if(answers[i] != 'B') {answerlabelB.setForeground(new Color(255,0,0));}
		if(answers[i] != 'C') {answerlabelC.setForeground(new Color(255,0,0));}
		if(answers[i] != 'D') {answerlabelD.setForeground(new Color(255,0,0));}
		
		Timer pause = new Timer(1500,new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				answerlabelA.setForeground(new Color(25,255,0));
				answerlabelB.setForeground(new Color(25,255,0));
				answerlabelC.setForeground(new Color(25,255,0));
				answerlabelD.setForeground(new Color(25,255,0));
				
				answer = ' ';
				seconds =10;
				seconds_left.setText(String.valueOf(seconds));
				buttonA.setEnabled(true);
				buttonB.setEnabled(true);
				buttonC.setEnabled(true);
				buttonD.setEnabled(true);
				i++;
				nextQuestion();
			}	
		});
		pause.setRepeats(false);
		pause.start();
	}
}
